genero = input("Digite o seu gênero: (M - Masculino, F - Feminino)\n").upper()

if genero == "M":
    print("Você escolheu masculino.")
elif genero == "F":
    print("Você escolheu feminino.")
else:
    print("Opção fora das opções.")
