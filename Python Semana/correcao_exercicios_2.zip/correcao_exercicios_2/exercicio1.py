numero1 = float(input("Digite o primeiro valor: "))
numero2 = float(input("Digite o segundo valor: "))

if numero1 > numero2:
    print("O maior número é:",numero1)
else:
    print("O maior número é:",numero2)