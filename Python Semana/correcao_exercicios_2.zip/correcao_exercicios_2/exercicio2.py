numero = float(input("Digite um número: "))

if numero >= 0:
    print("Positivo!")
else:
    print("Negativo!")